/**
 *
 * @param targets - The target IDs of both the anchor tags and text wrapper. should be an array of objects [{text: "text-target-id", url: "url-target-id"}]
 * @param items - An array of items to display in each target. Should be an array of objects [{phrase: "Phrase to type", url: "url to direct visitors to"}]
 * @param args - Additional argument overrides, as an object {time_between_words: 20, typing_speed: 50}.
 * @constructor
 */
function Typer(targets, items, args) {
    this.elements = [];
    for (i = 0; i < targets.length; i++) {
      this.elements.push({
        text: document.getElementById(targets[i].text),
        url: document.getElementById(targets[i].url)
      });
      items.push(items[0]);
      items.shift();
    }
    this.phraseElement = this.elements[0].text;
    this.urlElement = this.elements[0].url;
    this.args = args;
    this.args.typing_speed = this.args.typing_speed === undefined
      ? 50
      : this.args.typing_speed;
    this.args.time_between_words = this.args.time_between_words === undefined
      ? 20
      : this.args.time_between_words;
    this.waitTimer = 0;
    this.phrases = items;
    this.word = {
      current: [],
      currentLetter: "",
      length: 0
    };
    this.interval = false;
  
    /**
     * Selects the next phraseElement to display the content.
     */
    this.selectNextElement = function() {
      this.elements.push(this.elements[0]);
      this.elements.shift();
      this.phraseElement = this.elements[0].text;
      this.urlElement = this.elements[0].url;
    };
  
    /**
     * Grabs the next item from the phrases array, and rearranges the array
     * @returns {*}
     */
    this.getNextPhrase = function() {
      this.phrases.push(this.phrases[0]);
      this.phrases.shift();
      this.word.current = this.phrases[0].phrase.split("");
      this.word.length = this.word.current.length;
      this.urlElement.setAttribute("href", this.phrases[0].url);
      return this.word.current;
    };
  
    /**
     * Types the next letter in the current word
     * @returns {*}
     */
    this.typeLetter = function() {
      this.word.currentLetter = this.word.current[0];
      this.word.current.shift();
      this.phraseElement.innerHTML =
        this.phraseElement.innerHTML + this.word.currentLetter;
      if (!this.hasLetters()) {
        this.waitTimer = this.args.time_between_words;
        this.phraseElement.classList.remove("js--is-animating");
        this.selectNextElement();
      }
    };
  
    /**
     * Checks to see if the current word has any letters to display
     * @returns {boolean}
     */
    this.hasLetters = function() {
      return this.word.current.length > 0;
    };
  
    /**
     * Deletes a letter from the end of the current phrase
     */
    this.deleteLetter = function() {
      if (this.phraseElement.innerHTML.length > 0) {
        this.phraseElement.innerHTML = this.phraseElement.innerHTML.substring(
          0,
          this.phraseElement.innerHTML.length - 1
        );
      } else {
        this.getNextPhrase();
      }
    };
  
    /**
     * Sets the type interval for the function
     * @param self
     */
    this.typeInterval = function(self) {
      if (self.waitTimer === 0) {
        self.phraseElement.classList.add("js--is-animating");
        if (self.hasLetters()) {
          self.typeLetter();
        } else {
          self.deleteLetter();
        }
      } else {
        self.waitTimer--;
      }
    };
  
    /**
     * Run this in the JS to run the timer
     */
    this.type = function() {
      typeObject = this;
      this.interval = setInterval(function() {
        typeObject.typeInterval(typeObject);
      }, this.args.typing_speed);
    };
  }
  
  //In my personal version, this data is passed from an external source.
  
  
  var typer = new Typer(
    [
      { text: "text-1", url: "url-1" },
      { text: "text-2", url: "url-2" },
      { text: "text-3", url: "url-3" }
    ],
    [
      {
        phrase: "Instagram Stories",
        url: "http://www.instagram.com"
      },
      {
        phrase: "Tweet Chats",
        url: "http://www.twitter.com"
      },
      {
        phrase: "Stories",
        url: "/blog"
      },
      {
        phrase: "Podcasts",
        url: "http://www.stitcher.com"
      },
      {
        phrase: "Snapchat",
        url: "http://www.snapchat.com"
      }
    ],
    {
      /*Arg overrides can go here*/
    }
  );
  typer.type();
  